## RGB LED Remote control
A Flutter app which can control RGB LED Strip lights & Bulbs. `(Device must have IR Sensor)`

This app designed for Sylvania RGB remote (24Keys).

### Screenshot
<img src="https://github.com/user-attachments/assets/4e7acaca-097f-46b0-abd3-2346da9f91d1" width="320">  

### Download
[Google Play](https://play.google.com/store/apps/details?id=io.github.chayanforyou.rgbremote)
